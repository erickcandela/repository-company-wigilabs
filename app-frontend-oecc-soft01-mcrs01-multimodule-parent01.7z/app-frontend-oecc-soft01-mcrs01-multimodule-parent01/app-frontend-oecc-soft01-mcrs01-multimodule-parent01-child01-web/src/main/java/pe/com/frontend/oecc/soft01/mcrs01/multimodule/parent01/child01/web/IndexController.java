package pe.com.frontend.oecc.soft01.mcrs01.multimodule.parent01.child01.web;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@ComponentScan(basePackages={"pe.com.frontend.oecc.soft01.mcrs01.multimodule.parent01"})
public class IndexController {

	@RequestMapping("/welcome")
	public ModelAndView executeWelcome() {
		return new ModelAndView("welcome");
	}

}