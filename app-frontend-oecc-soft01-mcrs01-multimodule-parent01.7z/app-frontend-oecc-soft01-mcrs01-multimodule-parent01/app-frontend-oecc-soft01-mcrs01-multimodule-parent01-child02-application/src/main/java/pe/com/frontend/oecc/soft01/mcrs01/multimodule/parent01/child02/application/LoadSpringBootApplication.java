package pe.com.frontend.oecc.soft01.mcrs01.multimodule.parent01.child02.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages={"pe.com.frontend.oecc.soft01.mcrs01.multimodule.parent01"})
public class LoadSpringBootApplication {

	public static void main (String[] args) {
		SpringApplication.run(LoadSpringBootApplication.class, args);
	}
}