package pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child04.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/soft01mcrs01")
public class IndexController {

	@GetMapping("/findIndex")
	public String index() {
		return "Bienvenido a Spring Boot - WIGILABS!";
	}

}