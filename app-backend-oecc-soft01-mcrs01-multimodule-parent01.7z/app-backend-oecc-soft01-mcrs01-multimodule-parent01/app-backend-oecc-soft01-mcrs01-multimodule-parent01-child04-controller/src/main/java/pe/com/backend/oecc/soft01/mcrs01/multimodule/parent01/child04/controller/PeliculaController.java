package pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child04.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child01.model.Pelicula;
import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child03.service.inte.PeliculaServiceInte;

@RestController
@RequestMapping("/api/soft01mcrs01")
public class PeliculaController {

	@Autowired(required = true)
	PeliculaServiceInte peliculaServiceInte;	
		
    @GetMapping("/findAllPeliculas")
    public ResponseEntity<List<Pelicula>> findAll() {
    	
    	List<Pelicula> objectPeliculaList = new ArrayList<Pelicula>();
    	objectPeliculaList = peliculaServiceInte.findAll();
    	
    	ResponseEntity<List<Pelicula>> objectResponseEntity = new ResponseEntity<>(objectPeliculaList, HttpStatus.OK);
    	
        return objectResponseEntity;
    }

    @PostMapping("/insertPelicula")
    public ResponseEntity<Long> insert(@RequestBody Pelicula objectModel) {
    	
    	Long resultado = Long.valueOf(0);
    	resultado = peliculaServiceInte.insert(objectModel);
    	
    	ResponseEntity<Long> objectResponseEntity = new ResponseEntity<>(resultado, HttpStatus.CREATED);
    	
        return objectResponseEntity;
    }
    
    @PutMapping({"/updatePelicula/{parametroPeliculaId}"})
    public ResponseEntity<Long> update(@PathVariable("parametroPeliculaId") Long id, @RequestBody Pelicula objectModel) {
    	
    	Long resultado = Long.valueOf(0);
    	resultado = peliculaServiceInte.update(id, objectModel);
    	
    	ResponseEntity<Long> objectResponseEntity = new ResponseEntity<>(resultado, HttpStatus.OK);
    	
        return objectResponseEntity;
    }
    
    @DeleteMapping({"/deletePelicula/{parametroPeliculaId}"})
    public ResponseEntity<Long> delete(@PathVariable("parametroPeliculaId") Long id) {
    	
    	Long resultado = Long.valueOf(0);
    	resultado = peliculaServiceInte.delete(id);
    	
    	ResponseEntity<Long> objectResponseEntity = new ResponseEntity<>(resultado, HttpStatus.NO_CONTENT);
    	
        return objectResponseEntity;
    }    
}