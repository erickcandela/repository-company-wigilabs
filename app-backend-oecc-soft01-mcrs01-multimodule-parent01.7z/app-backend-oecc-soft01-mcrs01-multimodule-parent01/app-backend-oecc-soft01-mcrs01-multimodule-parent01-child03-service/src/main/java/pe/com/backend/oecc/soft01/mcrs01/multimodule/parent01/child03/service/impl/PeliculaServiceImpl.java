package pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child03.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child01.model.Pelicula;
import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child02.repository.impl.PeliculaRepositoryImpl;
import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child02.repository.inte.PeliculaRepositoryInte;
import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child03.service.inte.PeliculaServiceInte;

@Service
public class PeliculaServiceImpl implements PeliculaServiceInte {
	
	private final static Logger logger = Logger.getLogger(PeliculaRepositoryImpl.class);
	
	@Autowired(required = true)
	PeliculaRepositoryInte peliculaRepositoryInte;
	
	@Override
	public List<Pelicula> findAll() {
		logger.info("PeliculaServiceImpl::findAll::Inicio");
		
		List<Pelicula> objectList = new ArrayList<Pelicula>();
		
		objectList = peliculaRepositoryInte.findAll();
		
		for (Pelicula objectModel : objectList) {
			System.out.println(objectModel.toString());
		}
		
		logger.info("PeliculaServiceImpl::findAll::Fin");
		
		return objectList;
	}	
	
	@Override
	public Long insert(Pelicula objectModel) {
		logger.info("PeliculaServiceImpl::insert::Inicio");
		
		Long resultado = Long.valueOf(0);
		
		resultado = peliculaRepositoryInte.insert(objectModel);
				
		logger.info("PeliculaServiceImpl::insert::Fin");
		
		return resultado;
	}
	
	@Override
	public Long update(Long id, Pelicula objectModel) {
		logger.info("PeliculaServiceImpl::update::Inicio");
		
		Long resultado = Long.valueOf(0);
		
		resultado = peliculaRepositoryInte.update(id, objectModel);
				
		logger.info("PeliculaServiceImpl::update::Fin");
		
		return resultado;
	}	
	
	@Override
	public Long delete(Long id) {
		logger.info("PeliculaServiceImpl::delete::Inicio");
		
		Long resultado = Long.valueOf(0);
		
		resultado = peliculaRepositoryInte.delete(id);
				
		logger.info("PeliculaServiceImpl::delete::Fin");
		
		return resultado;
	}
}