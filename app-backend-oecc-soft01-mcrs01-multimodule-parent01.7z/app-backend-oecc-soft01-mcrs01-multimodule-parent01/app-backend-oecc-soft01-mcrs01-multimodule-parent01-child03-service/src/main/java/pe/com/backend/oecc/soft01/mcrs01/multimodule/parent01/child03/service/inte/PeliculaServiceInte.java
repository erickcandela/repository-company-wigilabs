package pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child03.service.inte;

import java.util.List;

import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child01.model.Pelicula;

public interface PeliculaServiceInte {
	
	List<Pelicula> findAll();
	
	Long insert(Pelicula objectModel);
	
	Long update(Long id, Pelicula objectModel);
	
	Long delete(Long id);
}