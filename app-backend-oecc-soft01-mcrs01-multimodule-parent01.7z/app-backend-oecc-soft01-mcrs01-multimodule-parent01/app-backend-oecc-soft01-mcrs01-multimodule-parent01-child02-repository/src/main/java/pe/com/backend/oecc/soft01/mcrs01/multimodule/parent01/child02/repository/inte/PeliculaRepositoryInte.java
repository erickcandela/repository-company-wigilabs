package pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child02.repository.inte;

import java.util.List;

import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child01.model.Pelicula;

public interface PeliculaRepositoryInte {
	
	List<Pelicula> findAll();
	
	Long insert(Pelicula objectModel);
	
	Long update(Long id, Pelicula objectModel);
	
	Long delete(Long id);
}