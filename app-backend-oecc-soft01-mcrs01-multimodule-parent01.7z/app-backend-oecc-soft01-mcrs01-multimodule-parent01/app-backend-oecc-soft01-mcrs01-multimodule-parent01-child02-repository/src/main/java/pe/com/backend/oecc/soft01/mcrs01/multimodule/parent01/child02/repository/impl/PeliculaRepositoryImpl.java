package pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child02.repository.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child01.model.Pelicula;
import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child02.repository.inte.PeliculaRepositoryInte;

@Repository
public class PeliculaRepositoryImpl implements PeliculaRepositoryInte {
	
	private final static Logger logger = Logger.getLogger(PeliculaRepositoryImpl.class);
	
	@Autowired(required = true)
    JdbcTemplate jdbcTemplate;
		
	@Override
	public List<Pelicula> findAll() {
		logger.info("PeliculaRepositoryImpl::getAll::Inicio");
		
		String sql = "select * from schema_sys_demo_wigilabs.tb_mae_cat_peli";
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
		
		List<Pelicula> objectList = new ArrayList<Pelicula>();
		
		for(Map<String, Object> row:rows){
			Pelicula objectModel = new Pelicula();
			objectModel.setCodigo((String)row.get("codigo"));
			objectModel.setNombre((String)row.get("nombre"));
			objectList.add(objectModel);
		}
		
		logger.info("PeliculaRepositoryImpl::getAll::Fin");
		
		return objectList;
	}
	
	@Override
	public Long insert(Pelicula objectModel) {
		
		logger.info("PeliculaRepositoryImpl::insert::Inicio");
		
		Long resultado = Long.valueOf(0);
		
		String sql = "insert into schema_sys_demo_wigilabs.tb_mae_cat_peli (codigo, nombre, descripcion, usuario_creacion_fecha, usuario_creacion_ip, usuario_creacion_nombre, estado) values (?, ?, ?, ?, ?, ?, ?)" ;
		
		logger.debug("PeliculaRepositoryImpl::insert::sql = " + sql);
		
		Object[] objectArgs = new Object[7];
		objectArgs[0] = objectModel.getCodigo();
		objectArgs[1] = objectModel.getNombre();
		objectArgs[2] = objectModel.getDescripcion();
		objectArgs[3] = objectModel.getUsuarioCreacionFecha();
		objectArgs[4] = objectModel.getUsuarioCreacionIp();
		objectArgs[5] = objectModel.getUsuarioCreacionNombre();
		objectArgs[6] = objectModel.getEstado();
		
		for (int i = 0; i <objectArgs.length; i++) {
			logger.debug("PeliculaRepositoryImpl::insert::objectArgs[" + i + "] = " + objectArgs[i]);
		}
		
		logger.debug("PeliculaRepositoryImpl::insert::resutado = 0 ");
		
		jdbcTemplate.update(sql, objectArgs);
		
		resultado = Long.valueOf(1);
		
		logger.debug("PeliculaRepositoryImpl::insert::resutado = 1 ");
		
		logger.info("PeliculaRepositoryImpl::insert::Fin");
		
		return resultado;
	}	
	
	@Override
	public Long update(Long id, Pelicula objectModel) {
		
		logger.info("PeliculaRepositoryImpl::update::Inicio");
		
		Long resultado = Long.valueOf(0);
		
		String sql = "update schema_sys_demo_wigilabs.tb_mae_cat_peli"
				+ " set codigo = ?"   
				+ " , nombre = ?"  
				+ " , descripcion = ?" 
				+ " , usuario_creacion_fecha = ?" 
				+ " , usuario_creacion_ip = ?" 
			    + " , usuario_creacion_nombre = ?"
			    + " , estado = ?"
			    + " where pelicula_id = ?";
		
		logger.debug("PeliculaRepositoryImpl::update::sql = " + sql);
		
		Object[] objectArgs = new Object[8];
		objectArgs[0] = objectModel.getCodigo();
		objectArgs[1] = objectModel.getNombre();
		objectArgs[2] = objectModel.getDescripcion();
		objectArgs[3] = objectModel.getUsuarioCreacionFecha();
		objectArgs[4] = objectModel.getUsuarioCreacionIp();
		objectArgs[5] = objectModel.getUsuarioCreacionNombre();
		objectArgs[6] = objectModel.getEstado();
		objectArgs[7] = id;
		
		for (int i = 0; i <objectArgs.length; i++) {
			logger.debug("PeliculaRepositoryImpl::update::objectArgs[" + i + "] = " + objectArgs[i]);
		}		
		
		logger.debug("PeliculaRepositoryImpl::update::resutado = 0 ");
		
		jdbcTemplate.update(sql, objectArgs);
		
		resultado = Long.valueOf(1);
		
		logger.debug("PeliculaRepositoryImpl::update::resutado = 1 ");
		
		logger.info("PeliculaRepositoryImpl::update::Fin");
		
		return resultado;
	}
	
	@Override
	public Long delete(Long id) {
		
		logger.info("PeliculaRepositoryImpl::delete::Inicio");
		
		Long resultado = Long.valueOf(0);
		
		String sql = "delete from schema_sys_demo_wigilabs.tb_mae_cat_peli "
				+ "where pelicula_id = ?";
		
		Object[] objectArgs = new Object[1];
		objectArgs[0] = id;
		
		logger.debug("PeliculaRepositoryImpl::delete::resutado = 0 ");
		
		jdbcTemplate.update(sql, objectArgs);
				
		resultado = Long.valueOf(1);
		
		logger.debug("PeliculaRepositoryImpl::delete::resutado = 1 ");
		
		logger.info("PeliculaRepositoryImpl::delete::Fin");
		
		return resultado;
	}	
}