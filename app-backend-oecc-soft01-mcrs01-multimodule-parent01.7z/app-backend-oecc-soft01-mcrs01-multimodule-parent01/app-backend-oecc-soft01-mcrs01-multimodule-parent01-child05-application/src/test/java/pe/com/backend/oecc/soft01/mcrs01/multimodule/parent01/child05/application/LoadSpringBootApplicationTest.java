package pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child05.application;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child01.model.Pelicula;
import pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child03.service.inte.PeliculaServiceInte;

@AutoConfigureMockMvc
@ContextConfiguration(classes = LoadSpringBootApplication.class)
@SpringBootTest
@ComponentScan(basePackages={"pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01"})
public class LoadSpringBootApplicationTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired(required = true)
	PeliculaServiceInte peliculaServiceInte;
	
	/*SI SE VA EJECUTAR ESTE METODO ENTONCES LOS DEMAS METODOS DEBEN ESTAR COMENTADOS*/
	/*@Test
	public void testIndex() throws Exception {
		this.mockMvc.perform(get("http://localhost:8081/api/soft01mcrs01/findIndex")).andDo(print()).andExpect(status().isOk()).andExpect(content().string(containsString("Bienvenido")));
	}*/
	
	/*SI SE VA EJECUTAR ESTE METODO ENTONCES LOS DEMAS METODOS DEBEN ESTAR COMENTADOS*/
	/*@Test
	public void testFindAllPeliculas() throws Exception {
				
		List<Pelicula> objectList = new ArrayList<Pelicula>();
		
		objectList = peliculaServiceInte.findAll();
		
		assertTrue(objectList.size() >= 0);		
	}*/
	
	/*SI SE VA EJECUTAR ESTE METODO ENTONCES LOS DEMAS METODOS DEBEN ESTAR COMENTADOS*/
	/*@Test
	public void testInsertPelicula() throws Exception {
		
		UUID uuid = UUID.randomUUID();
		
		Date fechaDate = Calendar.getInstance().getTime();  		
		DateFormat dateFormat01 = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
        String fechaString = dateFormat01.format(fechaDate);  
		
		DateFormat dateFormat02 = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
		Date date = dateFormat02.parse(fechaString);
        Timestamp timestamp = new Timestamp(date.getTime());
		
		Pelicula objectModel = new Pelicula();
		objectModel.setCodigo(uuid.toString());
		objectModel.setNombre("Matrix 3");
		objectModel.setDescripcion("Matrix 3 es una película de acción");
		objectModel.setUsuarioCreacionFecha(timestamp);
		objectModel.setUsuarioCreacionIp("192.168.1.0");
		objectModel.setUsuarioCreacionNombre("OECANDELA");
		objectModel.setEstado("1");

		Long resultado = Long.valueOf(0);
		resultado = peliculaServiceInte.insert(objectModel);
		
		assertEquals(1, resultado);		
	}*/	
	
	/*SI SE VA EJECUTAR ESTE METODO ENTONCES LOS DEMAS METODOS DEBEN ESTAR COMENTADOS*/
	/*@Test
	public void testUpdatePelicula() throws Exception {
		
		UUID uuid = UUID.randomUUID();
		
		Date fechaDate = Calendar.getInstance().getTime();  		
		DateFormat dateFormat01 = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
        String fechaString = dateFormat01.format(fechaDate);  
		
		DateFormat dateFormat02 = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
		Date date = dateFormat02.parse(fechaString);
        Timestamp timestamp = new Timestamp(date.getTime());
		
		Pelicula objectModel = new Pelicula();
		objectModel.setCodigo(uuid.toString());
		objectModel.setNombre("Matrix 4");
		objectModel.setDescripcion("Matrix 4.1 es una película de acción");
		objectModel.setUsuarioCreacionFecha(timestamp);
		objectModel.setUsuarioCreacionIp("192.168.1.0");
		objectModel.setUsuarioCreacionNombre("OECANDELA");
		objectModel.setEstado("1");

		Long resultado = Long.valueOf(0);
		Long id = Long.valueOf(4);
		resultado = peliculaServiceInte.update(id, objectModel);
		
		assertEquals(1, resultado);		
	}*/	
	
	/*SI SE VA EJECUTAR ESTE METODO ENTONCES LOS DEMAS METODOS DEBEN ESTAR COMENTADOS*/
	@Test
	public void testDeletePelicula() throws Exception {
		
		UUID uuid = UUID.randomUUID();
		
		Date fechaDate = Calendar.getInstance().getTime();  		
		DateFormat dateFormat01 = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
        String fechaString = dateFormat01.format(fechaDate);  
		
		DateFormat dateFormat02 = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
		Date date = dateFormat02.parse(fechaString);
        Timestamp timestamp = new Timestamp(date.getTime());
		
		Pelicula objectModel = new Pelicula();
		objectModel.setCodigo(uuid.toString());
		objectModel.setNombre("Matrix 4");
		objectModel.setDescripcion("Matrix 4.1 es una película de acción");
		objectModel.setUsuarioCreacionFecha(timestamp);
		objectModel.setUsuarioCreacionIp("192.168.1.0");
		objectModel.setUsuarioCreacionNombre("OECANDELA");
		objectModel.setEstado("1");

		Long resultado = Long.valueOf(0);
		Long id = Long.valueOf(5);
		resultado = peliculaServiceInte.delete(id);
		
		assertEquals(1, resultado);		
	}
}