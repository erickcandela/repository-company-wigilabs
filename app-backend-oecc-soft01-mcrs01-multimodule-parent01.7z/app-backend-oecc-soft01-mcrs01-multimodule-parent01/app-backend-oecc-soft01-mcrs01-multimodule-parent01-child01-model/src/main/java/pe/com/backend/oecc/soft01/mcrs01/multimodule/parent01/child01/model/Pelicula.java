package pe.com.backend.oecc.soft01.mcrs01.multimodule.parent01.child01.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="schema_sys_demo_wigilabs.tb_mae_cat_peli")
public class Pelicula {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)    
    @Column(name="pelicula_id", unique = true, nullable = false)
    private Long identificador;
    
    @Column(name="codigo", unique = false, nullable = true)
    private String codigo;
    
    @Column(name="nombre", unique = false, nullable = true)
    private String nombre;
    
    @Column(name="descripcion", unique = false, nullable = true)
    private String descripcion;
    
    @Column(name="usuario_creacion_fecha", unique = false, nullable = true)
    private Timestamp usuarioCreacionFecha; 
    
    @Column(name="usuario_creacion_ip", unique = false, nullable = true)
    private String usuarioCreacionIp; 
    
    @Column(name="usuario_creacion_nombre", unique = false, nullable = true)
    private String usuarioCreacionNombre;
    
    @Column(name="estado", unique = false, nullable = true)
    private String estado;    

	public Long getIdentificador() {
		return identificador;
	}

	public void setIdentificador(Long identificador) {
		this.identificador = identificador;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Timestamp getUsuarioCreacionFecha() {
		return usuarioCreacionFecha;
	}

	public void setUsuarioCreacionFecha(Timestamp usuarioCreacionFecha) {
		this.usuarioCreacionFecha = usuarioCreacionFecha;
	}

	public String getUsuarioCreacionIp() {
		return usuarioCreacionIp;
	}

	public void setUsuarioCreacionIp(String usuarioCreacionIp) {
		this.usuarioCreacionIp = usuarioCreacionIp;
	}

	public String getUsuarioCreacionNombre() {
		return usuarioCreacionNombre;
	}

	public void setUsuarioCreacionNombre(String usuarioCreacionNombre) {
		this.usuarioCreacionNombre = usuarioCreacionNombre;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}        
}